import{ao as r,ap as n}from"./index-Y0Xmm2MN.js";const t=(a,o)=>r.lang.round(n.parse(a)[o]);export{t as c};
