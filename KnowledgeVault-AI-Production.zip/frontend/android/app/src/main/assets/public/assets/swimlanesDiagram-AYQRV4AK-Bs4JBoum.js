import{c as r,s as e}from"./flowDiagram-IUGLLWBU-DGW5smMJ.js";import{_ as a}from"./index-Y0Xmm2MN.js";import"./chunk-5VM5RSS4-D2Kp6jH7.js";import"./chunk-XXDRQBXY-BY0tWIEm.js";import"./chunk-VQ5W62QI-DACl9ClN.js";import"./chunk-55XCU76K-9k3blVNJ.js";import"./channel-D2EPc3Gw.js";var o=a(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=r({styles:s});export{f as diagram};
